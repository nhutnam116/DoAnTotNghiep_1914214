# fishcatch5 > 2024-11-27 4:43pm
https://universe.roboflow.com/doan-i0kip/fishcatch5

Provided by a Roboflow user
License: CC BY 4.0

